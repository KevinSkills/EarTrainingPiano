using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntervalGame1 : RythmCommands
{


    // Start is called before the first frame update
    void Start()
    {

        StartCoroutine(playFurElise());
    }

    // Update is called once per frame
    void Update()
    {

    }

    IEnumerator playIt()
    {
        // Stop all notes in the beginning
        Note.StopAll();

        while (true)
        {
            beatsInMeasure = 3;

            measures = 2;
            // Pick a random note between 30 and 60
            int firstNote = Random.Range(10, 61);
            Note first = Note.FindNote(firstNote);

            // Pick a second note that is 3 higher or 4 higher with a 10% chance
            int secondNote = firstNote + 3;
            if (Random.Range(0, 101) < 10) secondNote++;
            Note second = Note.FindNote(secondNote);

            // Set the background color based on the interval
            if (secondNote - firstNote == 4) Camera.main.backgroundColor = Color.red;
            else Camera.main.backgroundColor = Color.green;

            // Play the first note on beat 1
            yield return SetBeat(0, 0);
            first.Play();

            // Play the second note on beat 1.5
            yield return SetBeat(0, 0.5f);
            second.Play();

            yield return SetBeat(currentBeat + 1/3f);
            second.Play();
            yield return SetBeat(currentBeat + 1/4f);
            second.Play();
            yield return SetBeat(currentBeat + 1/5f);
            second.Play();
            yield return SetBeat(currentBeat + 1 / 2f);
            Note.FindNote(second.number + 8).Play();

            yield return SetBeat(1, 0);
            second.Play();
            yield return SetBeat(1, 0.5f);



            // End the round
            yield return EndRound();
        }
    }



    IEnumerator playFurElise()
    {
        // Stop all notes in the beginning
        Note.StopAll();

        while (true)
        {
            beatsInMeasure = 4;
            measures = 2;
            bpm = 120;

            // Define the notes for F�r Elise
            Note E = Note.FindNote("E4");
            Note Dsharp = Note.FindNote("D#4");
            Note B = Note.FindNote("B3");
            Note D = Note.FindNote("D4");
            Note C = Note.FindNote("C4");
            Note A = Note.FindNote("A3");

            // Play the sequence
            yield return SetBeat(0, 0);
            E.Play();

            yield return SetBeat(0, 0.5f);
            Dsharp.Play();

            yield return SetBeat(0, 1f);
            E.Play();

            yield return SetBeat(0, 1.5f);
            Dsharp.Play();

            yield return SetBeat(0, 2f);
            E.Play();

            yield return SetBeat(0, 2.5f);
            B.Play();

            yield return SetBeat(0, 3f);
            D.Play();

            yield return SetBeat(0, 3.5f);
            C.Play();

            yield return SetBeat(1, 0);
            A.Play();

            // End the round
            yield return EndRound();
        }
    }

}
