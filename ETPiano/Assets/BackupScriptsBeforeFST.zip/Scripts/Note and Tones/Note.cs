using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Note
{


    public AudioClip clip;

    public int semiTonesUp;


    [HideInInspector]
    public AudioSource source;

    public string name;

    [HideInInspector]
    public int number;

    public void Stop()
    {
        source.Stop();
    }
    public void Play()
    {
        source.time = 0;
        source.Play();

        
    }


    public void PlayChord(string chordType)
    {
        StopAll();
        List<int> noteNumbers = NoteManager.singleton.findChord(chordType).noteNumbers;
        for (int i = 0; i < noteNumbers.Count; i++)
        {
            FindNote(number + noteNumbers[i]).Play();

        }

        

    }




}





