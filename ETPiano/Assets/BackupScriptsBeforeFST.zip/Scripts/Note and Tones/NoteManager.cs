using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using F1yingBanana.SfizzUnity;

public class NoteManager : MonoBehaviour
{
    static List<string> noteNames = new List<string>() { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    static List<string> noteNamesFlat = new List<string>() { "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B" };
    static List<string> solfa = new List<string>() { "Do", "Ra", "Re", "Me", "Mi", "Fa", "Fi", "So", "Le", "La", "Te", "Ti" };

    public List<Chord> chords = new List<Chord>();
    public static Note[] notes = new Note[88];

    public static NoteManager singleton;

    public SfizzPlayer Player;

    public string InitialSfzFile;

    private void Awake()
    {
        if(singleton != null)
        {
            Debug.LogError("Multiple Chordmanagers");
            Destroy(gameObject);
        }else
        {
            singleton = this;
        }

        string path = System.IO.Path.Combine(Application.streamingAssetsPath, InitialSfzFile);

        if (!Player.Sfizz.LoadFile(path))
        {
            Debug.LogWarning($"Sfz not found at the given path: {path}, player will remain silent.");
        }


    }
    public Chord findChord(string name)
    {
        foreach (Chord c in chords)
        {
            if (c.name.Equals(name)) return c;
        }

        return null;
    }

    public Note FindNote(int number)
    {
        foreach (Note n in notes)
        {
            if (n.number == number) return n;
        }
        return null;
    }

    public Note FindNote(string noteName)
    {
        noteName = ToSharp(noteName);
        foreach (Note n in notes)
        {
            if (n.name.Equals(noteName)) return n;
        }
        Debug.LogError("bad");
        return null;

    }

    
    public void StopAll()
    {
        foreach (Note n in notes)
        {
            n.Stop();
        }
    }


    private void Update()
    {
        /*foreach (Note n in Note.notes)
        {
            if (n.source.isPlaying && (n.source.clip.length - n.source.time < 0.2f)) n.source.time = n.source.clip.length/2;
        }*/
    }

    string ToSharp(string noteName)
    {
        for (int i = 0; i < noteNames.Count; i++)
        {
            noteName = noteName.Replace(noteNamesFlat[i], noteNames[i]);
        }
        return noteName;
    }

    public string NumToName(int number)
    {
        number += 9;
        int octaves = ((int)(number / 12));

        number -= octaves * 12;

        return "" + noteNames[number] + octaves;
    }

    public int NameToNum(string noteName)
    {
        noteName = ToSharp(noteName);
        int octave;
        string forParse = ToSharp("" + noteName[noteName.Length - 1]);
        if (!int.TryParse(forParse, out octave))
        {
            Debug.LogError("Parse failed : returning -1");
            return -1;
        }

        noteName = noteName.Remove(noteName.Length - 1, 1);

        return -9 + octave * 12 + noteNames.IndexOf(noteName);
    }

    public string NumToSolfa(int num)
    {
        num = num % 12;
        num = (num < 0) ? num + 12 : num;
        return solfa[num];
    }

}

[System.Serializable]
public class Chord
{
    public string name;

    public List<int> noteNumbers = new List<int>();

}
