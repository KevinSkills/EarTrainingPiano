using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ScaleTemplate 
{

    public string name;

    public int[] notesInScale;

}
