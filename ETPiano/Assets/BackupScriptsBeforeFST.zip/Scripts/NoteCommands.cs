using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoonSharp.Interpreter;
using System;
public class NoteCommands : MonoBehaviour
{
    public Note findNote(DynValue r)
    {
        Note n = new Note();

        if (r.Type == DataType.Number) n = Note.FindNote((int)r.CastToNumber());
        else n = Note.FindNote(r.CastToString());

        return n;
    }


    public DynValue convertNote(DynValue r)
    {
        if (r.Type == DataType.Number) return DynValue.NewString(Note.NumToName((int)r.CastToNumber()));
        else return DynValue.NewNumber(Note.NameToNum(r.CastToString()));
    }

    public void defineChord(string s, DynValue noteNumbers)
    {
        

        Table table = noteNumbers.Table;
        NoteManager.singleton.findChord(s);

        Chord c = NoteManager.singleton.findChord(s);
        if (c == null)
        {
            c = new Chord();
            c.name = s;
        }

        
        for (int i = 1; i <= table.Length; i++)
        {
            c.noteNumbers.Add((int)table.Get(i).CastToNumber());
        }

        NoteManager.singleton.chords.Add(c);
    }


    public void playChord(DynValue note, string chordName)
    {
        findNote(note).PlayChord(chordName);
    }

}
