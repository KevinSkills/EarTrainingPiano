using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NoteGuessingGame : MonoBehaviour
{
    public Button startButton;
    public Button checkButton;
    public Button replayButton;
    public InputField inputField;
    public Text correctAnswerText;

    private int currentNoteNumber;
    private string currentNoteName;

    void Start()
    {
        startButton.onClick.AddListener(StartGame);
        checkButton.onClick.AddListener(CheckGuess);
        replayButton.onClick.AddListener(PlayCurrentNote);
        checkButton.interactable = false;
        replayButton.interactable = false;
    }

    void StartGame()
    {
        currentNoteNumber = Random.Range(30, 61);
        currentNoteName = Note.NumToName(currentNoteNumber);
        PlayCurrentNote();
        checkButton.interactable = true;
        replayButton.interactable = true;
        startButton.gameObject.SetActive(false);
    }

    void PlayCurrentNote()
    {
        Note.StopAll();
        Note.FindNote(currentNoteNumber).Play();
    }

    void CheckGuess()
    {
        string guess = inputField.text;
        if (guess == currentNoteName.Remove(currentNoteName.Length - 1, 1))
        {
            StartCoroutine(ShowCorrect());
        }
        else
        {
            correctAnswerText.text = "The correct answer was: " + currentNoteName;
            correctAnswerText.gameObject.SetActive(true);
            Invoke("HideCorrectAnswerText", 1f);
        }
    }

    IEnumerator ShowCorrect()
    {
        GetComponent<Image>().color = Color.green;
        yield return new WaitForSeconds(1f);
        GetComponent<Image>().color = Color.white;
        StartGame();
    }

    void HideCorrectAnswerText()
    {
        correctAnswerText.gameObject.SetActive(false);
        StartGame();
    }
}
