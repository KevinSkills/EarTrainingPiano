using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoonSharp.Interpreter;
using System;


public class RythmCommands : MonoBehaviour
{

    public float bpm;

    public int beatsInMeasure;

    public int measures;


    public float currentBeat;


    public RythmCommands() : this(120, 4, 1)
    {

    }

    public RythmCommands(float bpm, int beatsInMeasure, int measures)
    {
        this.bpm = bpm;

        this.beatsInMeasure = beatsInMeasure;

        this.measures = measures;

        this.currentBeat = 0;

    }
    public RythmCommands(RythmCommands c) : this(c.bpm, c.beatsInMeasure, c.measures)
    {

    }


    /// <summary>
    /// Set the player to the total amounts of beats b
    /// </summary>
    public IEnumerator SetBeat(float beat)
    {
        float b = beat - 1;

        float maxBeat = beatsInMeasure * measures -1;

        float theBeat = Mathf.Min(maxBeat, b);

        float toWait = (theBeat - currentBeat) * 60 / bpm;

        yield return new WaitForSeconds(toWait);
        
        currentBeat = theBeat;

    }

    /// <summary>
    /// Set the player to the m measure and mb beat
    /// </summary>
    public IEnumerator SetBeat(int measure, float measureBeat)
    {
        int m = measure - 1;
        float mb = measureBeat - 1;

        float maxBeat = beatsInMeasure * measures - 1;

        float b = m * beatsInMeasure + mb;

        float theBeat = Mathf.Min(maxBeat, b);

        float toWait = (theBeat - currentBeat) * 60 / bpm;

        yield return new WaitForSeconds(toWait);

        currentBeat = theBeat;

    }

    /// <summary>
    /// Waits for next round to start
    /// </summary>
    public IEnumerator EndRound()
    {
        float totalBeats = beatsInMeasure * measures;


        float toWait = Mathf.Max(0, (totalBeats - currentBeat) * 60 / bpm);

        yield return new WaitForSeconds(toWait);

        currentBeat = 0;



    }



}
