using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public interface IStatement
{
    IEnumerator Execute();
}

public interface ICondition
{
    IEnumerator Evaluate(System.Action<bool> callback);
}

public class CodeBlock : IStatement
{

    public List<IStatement> Statements { get; set; }

    public IEnumerator Execute()
    {
        foreach (var statement in Statements)
        {
            yield return statement.Execute();
        }
        yield return null;
    }
}

public class FunctionCall : IStatement
{
    public string Name { get; set; }
    public List<object> Arguments { get; set; }
    public string ReturnVariableName { get; set; }
    public float ReturnValue { get; private set; }

    public static Dictionary<string, float> VariablesDictionary = new Dictionary<string, float>();

    public IEnumerator Execute()
    {



        switch (Name)
        {
            case "set":
                if (Arguments.Count == 1 && !string.IsNullOrEmpty(ReturnVariableName))
                {
                    ReturnValue = System.Convert.ToSingle(Arguments[0]);
                    VariablesDictionary[ReturnVariableName] = ReturnValue;
                }
                break;

            case "get":
                ReturnValue = VariablesDictionary[(string)Arguments[0]];
                break;

            case "RandomValue":
                ReturnValue = RandomValue(Arguments);
                break;

            case "print":
                Print(Arguments);
                break;

            case "C":
                ReturnValue = FunctionC(Arguments);
                break;

            // ... other function names

            default:
                Debug.LogError("Unknown function name");
                throw new System.InvalidOperationException($"Unknown function name: {Name}");
        }
        
        if (!string.IsNullOrEmpty(ReturnVariableName))
        {
            VariablesDictionary[ReturnVariableName] = ReturnValue;
        }
        yield return null;
    }

    public float RandomValue(List<object> args) {
        if(args.Count != 2)
        {
            Debug.LogError("Wrong amount of arguments");
            return 0f;
        }
        try {
            var r = Random.Range(System.Convert.ToSingle(Arguments[0]), System.Convert.ToSingle(Arguments[1]));
            Debug.Log("Random value: " + r);
            return r;
        }
        catch
        {
            Debug.LogError("Something Went wrong");
            return 0f;
        }
        
    }

    public void Print(List<object> args)
    {
        if (!(args[0] is string))
        {
            Debug.LogError("Not a string");
            return;
        }
        Debug.Log("Printing true thing: " +  args[0]);
    }
    public float FunctionB(List<object> args) { /* ... */ return 0f; }
    public float FunctionC(List<object> args) { /* ... */ return 0f; }
}

public class Eval : ICondition
{
    public object LeftOperand { get; set; }
    public string Operator { get; set; }
    public object RightOperand { get; set; }

    private IEnumerator GetOperandValue(object operand, System.Action<float> callback)
    {
        if (operand is float)
        {
            callback?.Invoke((float)operand);
        }
        else if (operand is string operandString)
        {
            if (float.TryParse(operandString, out float parsedValue))
            {
                callback?.Invoke(parsedValue);
            }
            else
            {
                Debug.LogError("Invalid operand value; unable to parse to float.");
                throw new System.InvalidOperationException("Invalid operand value; unable to parse to float.");
            }
        }
        else if (operand is FunctionCall functionCall)
        {
            yield return functionCall.Execute();
            callback?.Invoke(functionCall.ReturnValue);
        }
        else
        {
            Debug.LogError("Invalid operand type: " + operand.GetType());
            throw new System.InvalidOperationException("Invalid operand type");
        }
        
    }

    public IEnumerator Evaluate(System.Action<bool> callback)
    {
        float leftValue = 0f;
        float rightValue = 0f;

        yield return GetOperandValue(LeftOperand, result => { leftValue = result; });
        yield return GetOperandValue(RightOperand, result => { rightValue = result; });


        switch (Operator)
        {
            case "<":
                callback?.Invoke( leftValue < rightValue);
                break;
            case ">":
                callback?.Invoke(leftValue > rightValue);
                break;
            // ... other operators
            default:
                Debug.LogError("Unknown operator");
                throw new System.InvalidOperationException($"Unknown operator: {Operator}");
        }
    }
}

public class MultiCondition : ICondition
{
    public ICondition LeftCondition { get; set; }
    public string Operator { get; set; }
    public ICondition RightCondition { get; set; }

    public IEnumerator Evaluate(System.Action<bool> callback)
    {
        bool leftResult = false; 
        bool rightResult = false; 

        yield return LeftCondition.Evaluate(result => { leftResult = result; });
        yield return RightCondition.Evaluate(result => { rightResult = result; });

        switch (Operator.ToLower())
        {
            case "and":
                callback?.Invoke(leftResult && rightResult);
                break;
            case "or":
                callback?.Invoke(leftResult || rightResult);
                break;
            default:
                Debug.LogError("Invalid operand type");
                throw new System.InvalidOperationException($"Unknown operator: {Operator}");
        }
    }
}

public class Not : ICondition
{
    public ICondition Condition { get; set; }

    public IEnumerator Evaluate(System.Action<bool> callback)
    {
        bool con = false;

        yield return Condition.Evaluate(result => { con = result; });
        callback?.Invoke(!con);
    }
}

public class If : IStatement
{
    public ICondition Condition { get; set; }
    public CodeBlock IsTrue { get; set; }
    public CodeBlock IsFalse { get; set; }

    public IEnumerator Execute()
    {

        bool r = false;
        yield return Condition.Evaluate(result => { r = result; });


        if (r)
        {
            
            yield return IsTrue?.Execute();
        }
        else
        {
            yield return IsFalse?.Execute();
        }
        yield return null;
    }
}
