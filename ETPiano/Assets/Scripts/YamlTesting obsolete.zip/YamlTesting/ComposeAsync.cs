using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;



public abstract class ComposeAsync
{


    public float bpm = 60;

    public int beatsInMeasure = 4;

    public int measures = 1;

    public float currentBeat = 0;


    /// <summary>
    /// Set the player to the total amounts of beats b
    /// </summary>
    public async Task SetBeat(float b)
    {
        float maxBeat = beatsInMeasure * measures - 1;

        float theBeat = Mathf.Min(maxBeat, b);

        float toWait = (theBeat - currentBeat) * 60 / bpm;
        await Task.Delay((int)(toWait * 1000f));


        currentBeat = theBeat;

    }

    /// <summary>
    /// Set the player to the m measure and mb beat
    /// </summary>
    public async Task SetBeat(int m, float mb)
    {
        float maxBeat = beatsInMeasure * measures - 1;

        float b = m * beatsInMeasure + mb;

        float theBeat = Mathf.Min(maxBeat, b);

        float toWait = (theBeat - currentBeat) * 60 / bpm;
        await Task.Delay((int)(toWait * 1000f));


        currentBeat = theBeat;

    }

    /// <summary>
    /// Waits for next round to start
    /// </summary>
    public async Task EndRound()
    {
        float totalBeats = beatsInMeasure * measures;

        

        float toWait = Mathf.Max(0, (totalBeats - currentBeat) * 60 / bpm);

        Debug.Log("waiting for " + toWait + " seconds");
        await Task.Delay((int)(toWait * 1000f));


        currentBeat = 0;



    }

}
