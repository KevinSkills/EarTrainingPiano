using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;




public class ComposeScript : Compose
{

    static List<string> functionNames = new List<string>() {
        "print",
        "c",
        "setFloat",
        "SetBool",
        "playNote",
        "setBeat",
        "endRound",
        "setFloat",
        "setBool",
        "get"};

    public Dictionary<string, object> myVars;
    public List<object> start;


    public static Coroutine myCoroutine;
    static MonoBehaviour runningTheCoroutine;


    //ienumerators return values
    string textReturn = "";
    bool conReturn = false;
    float numberReturn = 0f;
    object functionCallReturn = null;

    

    public static void runCode(MonoBehaviour runOn, ComposeScript c)
    {
        stopCode();
        c.myVars = new Dictionary<string, object>();
        runningTheCoroutine = runOn;
        myCoroutine = runningTheCoroutine.StartCoroutine(c.Execute(c.start));

    }

    public static void stopCode()
    {
        if (myCoroutine == null) return;
        runningTheCoroutine.StopCoroutine(myCoroutine);
    }


    public IEnumerator CoderFunctionCall(List<object> l) //returns object
    {
        string name = (string)l[0];

        switch (name)
        {
            case "print":
                yield return Text(l[1]);
                Debug.Log(textReturn);
                functionCallReturn = null;
                yield break;
            case "c":
                functionCallReturn = MyUtils.CalculateString(l[1].ToString(), myVars);
                yield break;
            case "setFloat":
                {
                    yield return Text(l[1]);
                    string varName = textReturn;
                    
                    yield return Number(l[2]);
                    float value = numberReturn;

                    myVars[varName] = value;

                    
                    functionCallReturn = null;
                    yield break;
                }
            case "setBool":
                {
                    yield return Text(l[1]);
                    string varName = textReturn;

                    yield return Condition(l[2]);
                    bool value = conReturn;

                    myVars[varName] = value;
                    functionCallReturn = null;
                    yield break;
                } 
            case "get": //do this later
                {
                    yield return Text(l[1]);
                    string varName = textReturn;
                    functionCallReturn = myVars[varName];
                    yield break;
                }
            case "endRound":
                yield return EndRound();
                functionCallReturn = null;
                yield break;
            case "playNote":
                yield return Text(l[1]);

                Note.FindNote(textReturn).Play();
                
                yield break;

        }
        yield return null;

    }

    

    public IEnumerator Execute(List<object> l) //returns nothing
    {
        if (ComposeScript.functionNames.Contains(l[0].ToString()))
        {
            yield return CoderFunctionCall(l);
            yield break;
        }

        switch (l[0].ToString())
        {
            case "code": //this means every next item in the list is a list to be executed
                for (int i = 1; i < l.Count; i++)
                {
                    yield return Execute((List<object>)l[i]);
                }
                break;
            case "if":
                {
                    yield return Condition(l[1]);
                    if (conReturn) yield return Execute((List<object>)l[2]);
                    else yield return Execute((List<object>)l[3]);
                    break;
                }
                
            case "while":
                {
                    int iterations = 0;
                    yield return Condition(l[1]);
                    while (conReturn && iterations < 1000)
                    {
                        yield return Execute((List<object>)l[2]);
                        iterations++;
                        yield return Condition(l[1]);
                    }

                    break;
                }
                
        }
    }

    public IEnumerator Text (object o) //returns string
    {
        if(o is string s)
        {
            textReturn = MyUtils.ReplaceVariables(s, myVars);
            yield break;
        }else if (!(o is List<object>)) {
            textReturn = o.ToString();
            yield break;
        }
        var l = (List<object>)o;
        if (ComposeScript.functionNames.Contains(l[0].ToString()))
        {
            yield return CoderFunctionCall(l);
            textReturn = functionCallReturn.ToString();
            yield break;
        }
        textReturn = "";
        yield break;
    }

    public IEnumerator Condition(object o) //returns bool
    {
        

        if (o is bool b)
        {
            conReturn = b;
            yield break;
        }else if (o is string s)
        {
            if(s.Equals("true")) conReturn = true;
            else if (s.Equals("false")) conReturn = false;
            else if (s.Contains("$"))
            {
                conReturn = (bool)myVars[s.Replace("$", "")];
            }
            yield break;
        }

        var l = (List<object>)o;
        if (ComposeScript.functionNames.Contains(l[0].ToString()))
        {
            yield return CoderFunctionCall(l);
            conReturn = (bool)(functionCallReturn);
            yield break;
        }

        


        switch (l[0].ToString())
        {
            case "e": 
                {
                    yield return Number(l[1]);
                    float left = numberReturn;

                    yield return Text(l[2]);
                    string op = textReturn;


                    yield return Number(l[3]);
                    float right = numberReturn;

                    switch (op)
                    {
                        case "=":
                            conReturn = (left == right);
                            yield break;
                        case "<":
                            conReturn = (left < right);
                            yield break;
                        case ">":
                            conReturn = (left > right);
                            yield break;
                    }
                    break;
                }

            case "m":
                {
                    yield return Condition(l[1]);
                    bool left = conReturn;

                    yield return Text(l[2]);
                    string op = textReturn;

                    yield return Condition(l[3]);
                    bool right = conReturn;

                    switch (op)
                    {
                        case "and":
                            conReturn = (left && right);
                            yield break;
                        case "or":
                            conReturn = (left || right);
                            yield break;
                    }
                    break;
                }
            case "n":
                {
                    yield return Condition(l[1]);
                    conReturn = !conReturn;
                    yield break;


                }
        }
        Debug.LogError("BAD");
        yield return null;
    }


    public IEnumerator Number(object n) //returns float
    {
        if (n is List<object> l)
        {
            if (ComposeScript.functionNames.Contains(l[0].ToString()))
            {
                yield return CoderFunctionCall(l);
                numberReturn = System.Convert.ToSingle(functionCallReturn);
                yield break;
            }
            else Debug.LogError("Bad");
        }


        string s = n.ToString();

        if (s.Contains("$"))
        {
            numberReturn = (float)myVars[s.Replace("$", "")];
        }else
        {
            numberReturn = float.Parse(s.Replace('.', ','));
            yield break;
        }

        
    }


}






