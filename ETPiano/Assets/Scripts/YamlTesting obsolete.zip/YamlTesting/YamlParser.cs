using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using YamlDotNet.Serialization;
using YamlDotNet.Serialization.NamingConventions;
using YamlDotNet.Core;

public class YamlParser : MonoBehaviour
{
    IDeserializer des;
    public TMP_InputField t;

    void Start()
    {
        // Removed var keyword to ensure class-level des field is being initialized
        des = new DeserializerBuilder()
            .WithTagMapping("!Eval", typeof(Eval))
            .WithTagMapping("!MultiCondition", typeof(MultiCondition))
            .WithTagMapping("!Not", typeof(Not))
            .WithTagMapping("!If", typeof(If))
            .WithTagMapping("!FunctionCall", typeof(FunctionCall))
            .WithTagMapping("!CodeBlock", typeof(CodeBlock))
            .Build();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            try
            {
                
                ComposeScript c = des.Deserialize<ComposeScript>(t.text);
                ComposeScript.runCode(this, c);

            }
            catch (Exception ex)  // Modified catch block to catch Exception and print its message
            {
                print("Something Went Wrong: " + ex.Message + "Trace: " +  ex.StackTrace);
            }
        }
    }

    public static T ToType<T>(object value)
    {
        return (T)value;
    }


}
